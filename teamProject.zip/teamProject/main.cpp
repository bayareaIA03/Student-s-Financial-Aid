/*
Authors: Sal, YeWint, Tino, Immad, Phillip
CS 124
Fall 2020
Description: 
    This program will find out if you are above or below
		the poverty line in the city of Fremont. \nIf you fall below it we can help.
		If you are above the poverty line, there are ways you can assist others
		if you choose.
*/

// includes
#include <iostream>
#include <string>
#include <fstream>

// for header files
#include "map.h"
#include "link.h"
#include "BinaryTree.h"

// to make life easier and type less
using std::cout;
using std::string;
using std::endl;
using std::cin;
using std::fstream;

  // declare global variables
	string name, helpAnswer, aboveHelpAnswer, choice, choice1, choice2;

  // constant for poverty line as found by our research for the city of fremont
  const int povertyLineInMonthlyDollarsInFremont = 1875;

  // declare global variables
  int income, 
      rent, 
      grocery, 
      utility, 
      costOfLiving,
      categoryMenuUserInput;

  // const string array to hold questions we want to ask the user
  const string questionsArray[4]= {"What is your monthly expenses in rent?",
                                  "What is your monthly expenses in grocery?",
                                  "What is your monthly expenses in utility?",
                                  "What is your monthly household income?"};

  // function prototypes
	void printFremontPovertyData();
	void setUserName();
	void greetTheUser();

  void setIncome();
  void setRent();
  void setGrocery();
  void setUtility();
  bool calculateUserPovertyStatus();

  void askIfTheUserWantsHelp();
  void storeUsersAnswerForHelp();
  bool storeAboveUsersAnswerForHelp();

  void printAboveCategoryMenu();
  void printBelowCategoryMenu();
  void takeCategoryMenuUserInput();

  void addUserThatNeedsHelpToFile(int categorySelection);
  void waitlist(string, string);

  void addAbovePovertyLineUsersToFile(int menuSelection, string name);
  bool searchForName(string fileName, string name);




  // //////////////////start of main////////////////////
	int main(){
   
    // ask user for their name and save in memory
		setUserName();

    // say hello to the user with their name
    // tell them about the program
		greetTheUser();

    // let the user know we're going to proceed
    cout << "\nLets get started.\n";

    // ask the user if they need assistance
    askIfTheUserWantsHelp();

    // store user's input
    storeUsersAnswerForHelp();

    // if yes do this
    if(helpAnswer == "yes"){

      // get the user's income
      setIncome();

// ****************BELOW THE POVERTY LINE ACTION HERE**************************
      if(calculateUserPovertyStatus()){
        // loop here if they want to repeat
        do{
        
          // print the menu for the user to see where they can get help
          printBelowCategoryMenu();

          // get user input for the menu selection
          takeCategoryMenuUserInput();

          // store the user's data in a text file
          addUserThatNeedsHelpToFile(categoryMenuUserInput);

          // if y, repeat
          cout << endl <<"Would you like to repeat the process?(y/n): ";
          cin >> choice; 

        }while(choice == "y");

// ****************ABOVE THE POVERTY LINE ACTION HERE**************************
      }else{

        // get user input if they want to help others
        // below functino call returns true if they answer yes
        if(storeAboveUsersAnswerForHelp()){
          
          // loop here if they want to repeat
          do{
        
            printAboveCategoryMenu();
            takeCategoryMenuUserInput();
            
            addAbovePovertyLineUsersToFile(categoryMenuUserInput, name);

            cout << std::endl <<"Would you like to repeat the process?(y/n): ";
            cin >> choice; 
            // choice=v.ask(choice);

           }while(choice == "y");
        }
      }
	  }
  }
  // //////////////////end of main////////////////////

	void setUserName(){

		// ask for the user's name
		cout << "\nHello, what is your name? ";

		// store user input
		getline(cin, name);
	}

  // prints the data we researched for the poverty line in fremont, ca
	void printFremontPovertyData(){

	    cout << "\nIn the Fremont city, there are a total of 13.1% people under poverty line. "
  		<<  "The amount of 1875/month low (45000/yr for 2) income and the family threshold " 
  		<<  "determines whether you are above or under poverty line and since you make it "
  		<<	"above the poverty line.\n";
	}

    // greet the user and give an overview of the program
		void greetTheUser(){
	
		// print out to the console 
		cout << "\nWassup " << name << "!" << endl;
		cout << "\nThis program will find out if you are above or below ";
		cout << "the poverty line in the city of Fremont. \nIf you fall below it we can help.\n";
		cout << "If you are above the poverty line, there are ways you can assist others ";
		cout << "if you choose.\n";
	}

  // store the user's income
  void setIncome(){

    cout << questionsArray[3] << endl;
    cin >> income;
  }
  
    // store the user's rent expense
  void setRent(){

    cout << questionsArray[0] << endl;
    cin >> rent;
  }

  // store the user's grocery expense
  void setGrocery(){

    cout << questionsArray[1] << endl;
    cin >> grocery;
  }

  // store the user's utility expense
  void setUtility(){

    cout << questionsArray[2] << endl;
    cin >> utility;
  }

  // calculate if the user's income falls below or above the poverty line in fremont
  // return true if below
  // return false if above
  bool calculateUserPovertyStatus(){

    // print the data for fremont's poverty line
    printFremontPovertyData();

    // if the user's income is less than the poverty line
    if(income < povertyLineInMonthlyDollarsInFremont){

      cout << "\nUnfortunately, you fall below the poverty line for the city of Fremont.\n";
      cout << "However, we do have resources to assist you.\n";

      return true;

    // if the user's income is above than the poverty line
    }else{

      // print out to the user to let them know they're above the poverty line
      cout << "\nSorry you're above the poverty line.\n";

      // ask the user if they want to help others below the poverty line
      cout << "We do provide opportunities to assist others, if you would like?(yes/no)\n";

      return false;
    }
  }

  // ask the user if they want assistance in the bewlow areas
  void askIfTheUserWantsHelp(){

    // ask the user if they want assistance in the given fields
    cout << "\n\nWould you like some assistance in any of the below areas? (yes/no)\n";
    cout << "\tJob Recommendation\n";
    cout << "\tRide sharing\n";
    cout << "\tFood\n";
  }

  // store the user's answer for help
  void storeUsersAnswerForHelp(){

    // loop if the string they enter is equal to yes or no
    while(!(helpAnswer == "yes" | helpAnswer == "no")){

      // get user input again
      cin >> helpAnswer;

      // if not yes or no tell them to try again
      if(!(helpAnswer == "yes" | helpAnswer == "no")){
          
          cout << "You entered an invalid response. Please try again.\n";
      }
    }
  }

  // store the user's answer for help
  // return true if yes
  // return false if no
  bool storeAboveUsersAnswerForHelp(){

    // loop if the string they enter is equal to yes or no
    while(!(aboveHelpAnswer == "yes" | aboveHelpAnswer == "no")){
      
      // get user input again
      cin >> aboveHelpAnswer;

      // if not yes or no tell them to try again
      if(!(aboveHelpAnswer == "yes" | aboveHelpAnswer == "no")){
          
          cout << "You entered an invalid response. Please try again.\n";
      }
    }

    // if answer is no return false
    if(aboveHelpAnswer == "no" | aboveHelpAnswer == "No"){

      return false;
    }

    return true;
  }

  // print the category menu for below the poverty line
  void printBelowCategoryMenu(){

    std::cout << "\nWhich category would you like help in?" << std::endl;
    std::cout << "1. Job Recommendation" <<std::endl;
    std::cout << "2. Ride sharing" <<std::endl;
    std::cout << "3. Food" <<std::endl;
    std::cout<< "Input option(1-3): ";
  }

  // print the category menu for above the poverty line
    void printAboveCategoryMenu(){

    std::cout << "\nWhich category would you like to help in?" << std::endl;
    std::cout << "1. Job Recommendation" <<std::endl;
    std::cout << "2. Ride sharing" <<std::endl;
    std::cout << "3. Food" <<std::endl;
    std::cout<< "Input option(1-3): ";
  }

  // store the user's answer for help
  void takeCategoryMenuUserInput(){

    // loop if the input is less than 1 or greater than 3
    while(categoryMenuUserInput < 1 | categoryMenuUserInput > 3){
      
      // get user input again
      cin >> categoryMenuUserInput;

      // if the input is less than 1 or greater than 3
      // tell them it's invalid and try again
      if(categoryMenuUserInput < 1 | categoryMenuUserInput > 3){
          
          cout << "You entered an invalid response. Please try again.\n";
      }
    }
  }

// users that wanted help, add them to a file and a map
void addUserThatNeedsHelpToFile(int categorySelection){
  
  // create map object
  Map m;

  // if the user chose category 1
  if(categorySelection==1){

    // call the print function in the map class
    m.print("job_recommendation.txt");
    
    // print out to the user
    std::cout << std::endl << "There are certain job available and stuff and may be you could be in the waitlist" <<std::endl;

        // call the waitlist
    waitlist("job_recommendation_waitlist.txt",name);
  }
    // if the user chose category 2
  else if(categorySelection==2){

    // call the print function in the map class
    m.print("ride_sharing.txt");

    // print out to the user
    std::cout << std::endl << "The school provide to certain amount of people with bus cards and may be you could be in the waitlist" <<std::endl;

    // call the waitlist
    waitlist("ride_sharing_waitlist.txt",name);
  }
    // if the user chose category 3
  else if(categorySelection==3){

    // call the print function in the map class
    m.print("food.txt");

    // print out to the user
    std::cout << std::endl << "There are other programs such as Ohlone Pantry that could help too and may be you could be in the waitlist" <<std::endl;

    // call the waitlist 
    waitlist("food_waitlist.txt",name);
  }
}

void waitlist(string fileName, string userName){

  // create head and tail pointer for linked list
  node* head;
  node* tail;

  // local variable
  string reply;

  // linked list object
  link l;

  // binary tree object
  BinaryTree tree;

  // ask if the user wants to be added to the waitlist
  cout << "\nWould you like to be in the waitlist?(y/n): \n";

  // take user input
  cin >> reply;

  // if y add to the queue and binary tree
  if(reply== "y"){ 

    // add to the queue
    l.createQueue(head, tail,fileName,userName);

    // add to the binary tree
    tree.insertNode(userName);
  }

  // ask if the user wants to see th enames in the list
  cout<<"\nwould you like to see the names in the list?(y/n): \n";

  // take user input
  cin >> reply;

  // if yes, print the linked list and the tree
  if(reply=="y"){

    // linked list's print function
    l.print(head);

    // binary tree's print function
    // tree.displayInOrder();
  }
}

// users that are above the poverty line, add them to a file 
void addAbovePovertyLineUsersToFile(int menuSelection, string name){

  // local variables
  bool b;
  std::string x;

  // fstream object
  std::ofstream file; 

  // if the user selected option 1
  if(menuSelection==1){
    
    // search the file to see if the user's name is already in the list
    b=searchForName("job_recommendation.txt",name);
    if(b==false){

    // ask user for contact info
    std::cout << "Please add a phone number or email for contact: ";

    // take user input
    std::cin >> x;

    // open the file in append mode
    file.open ("1.txt", std::ios::app);

    // write the name to the file with the contact info
    file << std::endl << name << "," << x ;

    // close the file
    file.close();
    }
  }

    // if the user selected option 2
  else if(menuSelection==2){

    // search the file to see if the user's name is already in the list
    b=searchForName("ride_sharing.txt",name);
    if(b==false){

    // ask user for contact info
    std::cout << "Please add a phone number or email for contact: ";

    // take user input
    std::cin >> x;

    // open the file in append mode
    file.open ("2.txt", std::ios::app);

    // write the name to the file with the contact info
    file << std::endl << name << "," << x << std::endl;

    // close the file
    file.close();
    }
  }

    // if the user selected option 3
  else if(menuSelection==3){

    // search the file to see if the user's name is already in the list
    b=searchForName("food.txt",name);
    if(b==false){

    // ask user for contact info
    std::cout << "Please add a phone number or email for contact: ";
    
    // take user input
    std::cin >> x;

    // open the file in append mode
    file.open ("3.txt", std::ios::app);

    // write the name to the file with the contact info
    file << std::endl << name << "," << x << std::endl;

    // close the file
    file.close();
    }
  }
  std::cout << "Thank you for helping out" <<std::endl;
}

// search for the user's name
// return true if found
// return false if not found
bool searchForName(string fileName, string name){

  // local variables
  int k;
  std::string g,st1;

  // fstream object
  std::ifstream file;

  // open the file
  file.open (fileName);

  // loop while not at the end of file
  while(!file.eof()){
  
  // get the line of file store it in g
  getline(file,g);

  // find the comma in the string, set that position in string to k
  for(int i=0;i<g.size();i++){
    if(g[i]==','){
      k=i;
    }
  }

  // st1 equals the substring from 0th position to kth position
  st1=g.substr(0,k);

  // if st1 is equal to the name passed by parameter
  if(name ==st1){

    // tell the user their name is already in the list
    std::cout << "Name already in list."<< std::endl;
    return true;
  }
  }
  return false;
}

