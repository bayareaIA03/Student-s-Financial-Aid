#include <iostream>
#include <string>
#include <string>

// to make life easier
using std::string;
using std::cout;
using std::endl;

class BinaryTree{

  private:
    
    struct TreeNode{

      // holds the value in the node
      string value;

      // pointer to the left child node
      TreeNode *left;

      // pointer to the right child node
      TreeNode *right;
    };

    // private member
    // pointer to the root node
    TreeNode *root;

    // private member functions

    // inserts a node into the tree
    void insert(TreeNode *&nodePtr, TreeNode *&newNode){

      // if the node pointer parm is null
      if(nodePtr == NULL){

        // set the node pointer to the newNode
        nodePtr = newNode;

        // when node pointer has a value
        // check if newNode value is less than node pointer
      }else if(newNode->value < nodePtr->value){

        // if the value is less, insert it to the left leaf
        insert(nodePtr->left, newNode);

      // if value is greate insert it to the right leaf
      }else{
        
      // if value is greate insert it to the right leaf
        insert(nodePtr->right, newNode);
      }
    }

    // display the nodes and their values in the tree in order
    void displayInOrder(TreeNode *nodePtr) const {

      // if node pointer is true (not null)
      if(nodePtr){

        // recursive call to print the left leaf nodes
        displayInOrder(nodePtr->left);

        // cout the value of node pointer
        cout << nodePtr->value << endl;

        // recursive call to print the right leaf nodes
        displayInOrder(nodePtr->right);
      }
    }

    public:

      // constructor
      BinaryTree(){

        // set root pointer to null
        root = NULL;
      }

      // inserts a node to the tree with string as a parameter
      // public function to insert
      void insertNode(string name){

        // create pointer of treeNode object
        TreeNode *newNode = NULL;

        // dynamically create a node
        newNode = new TreeNode;

        // assign the parameter to the value of the new node
        newNode->value = name;

        // set both leaf nodes of the new node to null
        newNode->left = newNode->right = NULL;

        // call private function to insert
        insert(root, newNode);
      }

      // publif function to print the tree's nodes in order
      void displayInOrder() const {

        // call the private function to print
        displayInOrder(root);
      }
};
