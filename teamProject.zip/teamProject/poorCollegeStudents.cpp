#include <iostream>
using std::cout; using std::cin; using std::endl;

struct node{ //the making of nodes
	 std::string data;
	 node *next; 
};

class link
{
    private:
        node* head; //conceled the head and tail pointers 
        node* tail;

    public:
		// example - scholarship, pantry,  tuition, transporation,
		void createQueue(std::string character);
		void add_at_end(std::string word);
		std::string remove_at_begin();
		link();

};
int main(){

link a;
std::string name, reply, za;
char choices, option;
int houseIncome;
int counter = 0;
int cap = 2;
int povertythreshold = 39600;

std::cout << "would you like to start the program? Press 'Y' or 'N'"<<std::endl;
	std::cin>> choices;

do{
	cout<< "whats your name"<<endl;
	cin>> name;

	cout<<"what is your house income? "<<endl;
	cout<<"please include all governmental aid as well."<<endl;
	cin>>houseIncome;

	counter++;
// 39600 is annual income 
	
if (counter != cap){
	 if (houseIncome > povertythreshold){
		cout<<"you got enough dough bruh"<<endl;
		
	}
	else {
		a.createQueue(name);

	}
}
else{
cout<<"the queue is full would you like to try to get help from other students"<<endl;
cin>>reply; //
break;
}

cout<<"would you like to restart the entire program? Press 'Y' or 'N'"<<endl;
		cin>> choices;
}
while(choices=='Y'|| choices=='y');

cout<<"would you like to see the names in the list? Press 'Y' or 'N'"<<endl;
cin>>option;
if(option=='Y'|| option=='y'){
	for(int i=0; i<counter;i++){
		za=a.remove_at_begin();
		cout<<za<<" "<<endl;
	}
}

	return 0;
}


void link::createQueue(std::string character){	
	add_at_end(character);		
	
}

void link::add_at_end(std::string word){ 

	node *newnode = new node; 
	newnode->data=word;
	newnode->next=NULL;
			
	if(tail==NULL){ // if theres no nodes in list
		head=newnode;
		tail=newnode;
	}
		else{
			tail->next=newnode;
			tail=newnode; //the tail will connect to the newnode and the newnode will become the tail
		}
}

std::string link::remove_at_begin(){
std::string temp;
	if(head==NULL){
		cout<<"Node is empty. Can't remove a node."<<endl;
		
	}
		else{
			node *p=head;
			head=head->next;
			temp = p->data;
			delete p;
		}	
		return temp;
} 

link::link()//constructor is called when object is made. so this functions makes the head and tail pointers r
{
     head = NULL;// set to null becaue there is no nodes 
	tail = NULL;		
} 
