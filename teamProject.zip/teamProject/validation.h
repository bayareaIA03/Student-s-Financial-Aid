#include <string>
#include <iostream>
/**
This class only pass the string to make sure the string is yes or no in short form as a data validation. 
*/
class Valid{
  public:
  std::string ask(std:: string x);
};

std::string Valid::ask(std::string x){
  while(x != "y" && x != "n"){//this is to make sure that if its not y or n the loop will keep going and ask the user for input multiple times until it is y or n
    std::cout << "Invalid input, re-enter: ";
    std::cin >> x;
  }
  return x;//when it is y or n it will return the string
}