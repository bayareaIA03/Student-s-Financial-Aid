#include <iostream>
#include <fstream>
/**
THe link class is a class for all the functions of the linked list. The functions that we use are, create to make head and tail null, add at end and print to create the queue for our lab.
*/

//this is a struct to create nodes for the linked list
struct node{ //the making of nodes
	 std::string data;//has a data type of string to store names
	 node *next; //pointer is only to the next
};

class link{
  public:
  void create(node* &head,node* &tail);
  void add_at_end(std::string word, node* &head, node* &tail);
  void print(node* &head);
	void createQueue(node* &head,node* &tail,std::string name,std::string a);
  friend class data;

};

//this function pass trhough the head and tail so it makes sure the head and tail are null when passing by reference
void link::create(node* &head, node* &tail){
  head = nullptr;// set to null becaue there is no nodes 
	tail = nullptr;		
} 

//this is add at end fuction which will pass the word we wnnt to add to the list and passing head and tail so if the list were empty, the new word inputted will be the new head and tail 
void link::add_at_end(std::string word, node* &head, node* &tail){ 
  node *newnode = new node;  //create new node to add to list
  newnode->data = word; // the data part of the node will become the string

  if(head == nullptr){// if theres no nodes in list
    newnode->next = nullptr; //the new node next pointer would be pointing to the null
    head = newnode; //head will become the new newnode
    tail = newnode; //so will the tail
  }
  else{
    newnode->next=nullptr;//the tail will connect to the newnode and the newnode will become the tail
    tail->next = newnode; //the pointer of the tail will point to the new node
    tail = newnode; //has to set the new node as the new tail
  }
}

//the print function will print all the nodes in the list
void link::print(node* &head){
  std::cout << std::endl << "Here is a list of people in the waitlist" <<std::endl;
	while(head!=nullptr){//until the head pointer reaches the nullptr or the end of list
    std::cout << head->data <<std::endl; //data part of the nodes will be printed
    head = head->next; ////setting the head as the next pointer of the head so it will traverse
  }
}


//create queue is the overview of the queue that we plan on doing, which will store the names into the linked list after reading the text file and then depending on the list cap, it will add addtional name to the list or not
void link::createQueue(node* &head, node* &tail,std::string name,std::string a){
  create(head, tail); //this will make the linked list to a new list
  int counter = 0;
  int cap = 6; //has a cap for the waitlist so that it doesnt exceed
  std::string g;
  std::ifstream file;//calling ifstream to read file
  bool found=false;//this is to search the names as going along the list to maeke srue there are no dublicate
  
  file.open (name);
  while(!file.eof()){ //using while loop to read file and get lines to store names
    getline(file,g);
    add_at_end(g,head,tail); //each line will have each name only so by using add at end, it will queue into the list
    if(g==a){//this is a astatemnt that if the name is already in the list 
      found = true;//the found would become true and the person wont be added to the list at the end again
    }
    counter++; //how many ppl in the list
  }  
  file.close();
  if(found == true){//saying that the person is in the list and wont be added more
    std::cout << "You are already in the list" <<std::endl;
  }
  else{//if the name is not found
    if (counter >= cap){//and if the amounter of people in the list is full for us to help we can't add the person to the lsit
		  std::cout<<"Line is full. Please refer to the list of contacts who had offered to help or waitlist in an available spots in another category."<<std::endl;
	  }
	  else {//if there are available spots in the list
      std::ofstream of;//the ofstream would be called
      of.open (name, std::ios::app);//add the person's name to the text file
      of  <<  std::endl<<a;
      of.close();//close the file again after adding
		  add_at_end(a,head, tail);//add to the linked list as well
      std::cout << "You have been added to the list! We will contact you with more information. Be Safe!" <<std::endl;
	  }
  }
}