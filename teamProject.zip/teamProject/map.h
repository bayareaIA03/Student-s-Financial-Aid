#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>
/** The class map stores the data from the text file that is passed through and store it in the map which will store the data in an alphabetical order. Then the map fucntion will also print all the data in the map from the start for the user to see.
*/
class Map{
  public:
  void print(std::string);
};

//thsi function will pass the name of the text file that is needed to read from to map the data and print the map back.In this case, we will be storing the name and the contact information from the text file. Name as the key and contact as the value.
void Map::print(std::string name){
  std::string st1,st2,g; //this is declaring variable of strings for name and contact
  int k=0;//the place of the comma to break sentence
  std::map <std::string,std::string> m; //declaring the map
  std::map <std::string,std::string>::iterator pos;
  
  std::ifstream file;//calling the ifstream so that the file can be read
  //read file
  file.open (name);//opening the file name that was passed
  while(!file.eof()){//will read the file until the end of file
    getline(file,g);//this g is the whole sentence from each line
    for(int i=0;i<g.size();i++){//creating a for loop to find the comma
      if(g[i]==','){//when comma found
        k=i;//k will become the place of the comma in  that line
      }
    }

    st1=g.substr(0,k);//then the string in front of comma is the name
    st2=g.substr(k+1);//after comma is the contact information
    //this will be smae beccause, we save the name before and contact after comma when implementing

    //map it
    m[st1]=st2;//setting the strings as key and value of the map
  }  
  file.close();//after the whole fileis read, the file need to be closed
  //print it
  std::cout << "Here is a list of contacts who could help out in this category." <<std::endl;
  std::cout <<std::endl;
  std::cout << std::setw(25)  << std::left << "Name" << "Contact Information" <<std::endl;//setting width of the space to print the name to look neater and as a table of contacts
  for (pos = m.begin(); pos != m.end(); pos++){//thiss is the loop to traverse throught the whole map
    std::cout << std::setw(25)  << std::left << pos->first << pos->second <<std::endl;//printing the key first then the value 
  }
}  